
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import f1_score
import pickle

# Load data
df = pd.read_csv("pipeline/data/latest_reviews.csv")

# Features & Labels
X = df['REVIEW DESCRIPTION']
y = df['Sentiment_Label']

# Text to vector
vectorizer = TfidfVectorizer()
X_vect = vectorizer.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X_vect, y, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
score = f1_score(y_test, y_pred, average='weighted')
print("📊 F1 Score:", score)

# Save model and vectorizer
with open("pipeline/models/sentiment_model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("pipeline/models/vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)
